
from flask import Flask, render_template, request, redirect, send_file
import sqlite3
from io import BytesIO

from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
)
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4

app = Flask(__name__)


# Database connection
def get_db_connection():
    conn = sqlite3.connect("budget.db")
    conn.row_factory = sqlite3.Row
    return conn


# Create database tables
def create_table():
    conn = get_db_connection()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            amount REAL NOT NULL,
            category TEXT NOT NULL,
            date TEXT NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            id INTEGER PRIMARY KEY,
            monthly_income REAL NOT NULL
        )
    """)

    conn.execute("""
        INSERT OR IGNORE INTO settings (id, monthly_income)
        VALUES (1, 30000)
    """)

    conn.commit()
    conn.close()


# Dashboard
@app.route("/")
def home():
    conn = get_db_connection()

    rows = conn.execute(
        "SELECT * FROM expenses ORDER BY date DESC, id DESC"
    ).fetchall()

    expenses = [dict(row) for row in rows]

    income_row = conn.execute(
        "SELECT monthly_income FROM settings WHERE id = 1"
    ).fetchone()

    income = income_row["monthly_income"]

    conn.close()

    return render_template(
        "index.html",
        expenses=expenses,
        income=income
    )


# Add expense
@app.route("/add_expense", methods=["POST"])
def add_expense():
    name = request.form["name"]
    amount = float(request.form["amount"])
    category = request.form["category"]
    date = request.form["date"]

    if amount <= 0:
        return redirect("/")

    conn = get_db_connection()

    conn.execute("""
        INSERT INTO expenses (name, amount, category, date)
        VALUES (?, ?, ?, ?)
    """, (name, amount, category, date))

    conn.commit()
    conn.close()

    return redirect("/")


# Edit expense
@app.route("/edit_expense/<int:expense_id>", methods=["GET", "POST"])
def edit_expense(expense_id):
    conn = get_db_connection()

    if request.method == "POST":
        name = request.form["name"]
        amount = float(request.form["amount"])
        category = request.form["category"]
        date = request.form["date"]

        if amount <= 0:
            conn.close()
            return redirect("/")

        conn.execute("""
            UPDATE expenses
            SET name = ?, amount = ?, category = ?, date = ?
            WHERE id = ?
        """, (name, amount, category, date, expense_id))

        conn.commit()
        conn.close()

        return redirect("/")

    row = conn.execute(
        "SELECT * FROM expenses WHERE id = ?",
        (expense_id,)
    ).fetchone()

    expense = dict(row) if row else None

    conn.close()

    if expense is None:
        return redirect("/")

    return render_template("edit.html", expense=expense)


# Delete expense
@app.route("/delete_expense/<int:expense_id>", methods=["POST"])
def delete_expense(expense_id):
    conn = get_db_connection()

    conn.execute(
        "DELETE FROM expenses WHERE id = ?",
        (expense_id,)
    )

    conn.commit()
    conn.close()

    return redirect("/")


# Update monthly income
@app.route("/update_income", methods=["POST"])
def update_income():
    try:
        income = float(request.form["income"])

        if income < 0:
            return redirect("/")

        conn = get_db_connection()

        conn.execute(
            "UPDATE settings SET monthly_income = ? WHERE id = 1",
            (income,)
        )

        conn.commit()
        conn.close()

    except (ValueError, KeyError):
        return redirect("/")

    return redirect("/")


# Download PDF Report
@app.route("/download_report")
def download_report():
    conn = get_db_connection()

    expenses = conn.execute(
        "SELECT * FROM expenses ORDER BY date DESC, id DESC"
    ).fetchall()

    conn.close()

    pdf_buffer = BytesIO()

    document = SimpleDocTemplate(
        pdf_buffer,
        pagesize=A4
    )

    styles = getSampleStyleSheet()
    elements = []

    elements.append(
        Paragraph("Home Budget Tracker - Expense Report", styles["Title"])
    )

    elements.append(Spacer(1, 20))

    total = sum(float(expense["amount"]) for expense in expenses)

    elements.append(
        Paragraph(
            f"Total Number of Expenses: {len(expenses)}",
            styles["Normal"]
        )
    )

    elements.append(
        Paragraph(
            f"Total Expenses: Rs. {total:.2f}",
            styles["Normal"]
        )
    )

    elements.append(Spacer(1, 20))

    data = [
        ["ID", "Expense Name", "Category", "Amount", "Date"]
    ]

    for expense in expenses:
        data.append([
            str(expense["id"]),
            str(expense["name"]),
            str(expense["category"]),
            f"Rs. {float(expense['amount']):.2f}",
            str(expense["date"])
        ])

    table = Table(data, repeatRows=1)

    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#243b64")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 1, colors.grey),
        ("PADDING", (0, 0), (-1, -1), 8),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE")
    ]))

    elements.append(table)

    document.build(elements)

    pdf_buffer.seek(0)

    return send_file(
        pdf_buffer,
        as_attachment=True,
        download_name="Home_Budget_Expense_Report.pdf",
        mimetype="application/pdf"
    )


if __name__ == "__main__":
    create_table()
    app.run(debug=True)
